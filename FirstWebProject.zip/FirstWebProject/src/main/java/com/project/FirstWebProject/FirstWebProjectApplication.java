package com.project.FirstWebProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstWebProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstWebProjectApplication.class, args);
	}

}
